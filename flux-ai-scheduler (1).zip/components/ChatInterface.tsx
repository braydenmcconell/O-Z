
import React, { useState, useRef, useEffect } from 'react';
import { Send, User, Bot, Loader2, Mic, MicOff, Search, MapPin, BrainCircuit, ExternalLink } from 'lucide-react';
import { ChatMessage } from '../types.ts';

interface ChatInterfaceProps {
  messages: ChatMessage[];
  onSendMessage: (msg: string, mode?: 'standard' | 'complex' | 'search' | 'maps') => Promise<void>;
  onVoiceInput: (blob: Blob) => Promise<void>;
  isLoading: boolean;
}

export const ChatInterface: React.FC<ChatInterfaceProps> = ({ messages, onSendMessage, onVoiceInput, isLoading }) => {
  const [input, setInput] = useState('');
  const [mode, setMode] = useState<'standard' | 'complex' | 'search' | 'maps'>('standard');
  const [isRecording, setIsRecording] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;
    onSendMessage(input, mode);
    setInput('');
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
        onVoiceInput(blob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (err) {
      console.error("Mic access denied", err);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 border-l border-slate-800">
      <div className="p-4 border-b border-slate-800 flex items-center justify-between">
        <div className="flex flex-col">
          <h2 className="font-bold flex items-center gap-2 text-white">
            <Bot className="w-5 h-5 text-indigo-400" />
            Flux Intelligence
          </h2>
          <div className="flex gap-2 mt-2">
            {[
              { id: 'standard', icon: Bot, label: 'Fast' },
              { id: 'complex', icon: BrainCircuit, label: 'Think' },
              { id: 'search', icon: Search, label: 'Search' },
              { id: 'maps', icon: MapPin, label: 'Maps' }
            ].map((m) => (
              <button
                key={m.id}
                onClick={() => setMode(m.id as any)}
                className={`text-[10px] px-2 py-0.5 rounded-full transition-all border ${
                  mode === m.id 
                    ? 'bg-indigo-600 border-indigo-400 text-white shadow-sm shadow-indigo-500/50' 
                    : 'bg-slate-800 border-slate-700 text-slate-400 hover:border-slate-500'
                }`}
              >
                {m.label}
              </button>
            ))}
          </div>
        </div>
        {isLoading && <Loader2 className="w-4 h-4 animate-spin text-indigo-400" />}
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((m) => (
          <div key={m.id} className={`flex gap-3 ${m.role === 'user' ? 'flex-row-reverse' : ''}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
              m.role === 'user' ? 'bg-indigo-600 shadow-lg shadow-indigo-600/20' : 'bg-slate-800 border border-slate-700/50'
            }`}>
              {m.role === 'user' ? <User className="w-4 h-4 text-white" /> : <Bot className="w-4 h-4 text-indigo-400" />}
            </div>
            <div className={`max-w-[85%] space-y-2`}>
              <div className={`px-4 py-2.5 rounded-2xl text-sm leading-relaxed shadow-sm ${
                m.role === 'user' 
                  ? 'bg-indigo-600 text-white rounded-tr-none' 
                  : 'bg-slate-800 text-slate-200 rounded-tl-none border border-slate-700/50'
              }`}>
                {m.isThinking && (
                  <div className="mb-2 p-2 bg-indigo-900/30 border-l-2 border-indigo-500 rounded text-xs text-indigo-300 italic">
                    AI thought process enabled...
                  </div>
                )}
                {m.content}
              </div>
              {m.groundingLinks && m.groundingLinks.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-1">
                  {m.groundingLinks.map((link, idx) => (
                    <a
                      key={idx}
                      href={link.web?.uri || link.maps?.uri}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 px-2 py-1 bg-slate-800 border border-slate-700 rounded-lg text-[10px] text-slate-400 hover:text-indigo-400 hover:border-indigo-500/50 transition-all"
                    >
                      <ExternalLink className="w-3 h-3" />
                      <span className="truncate max-w-[100px]">{link.web?.title || link.maps?.title || 'Source'}</span>
                    </a>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      <form onSubmit={handleSubmit} className="p-4 border-t border-slate-800 bg-slate-900/50">
        <div className="flex gap-2 items-center">
          <button
            type="button"
            onClick={isRecording ? stopRecording : startRecording}
            className={`p-3 rounded-xl transition-all ${
              isRecording 
                ? 'bg-rose-600 text-white animate-pulse' 
                : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            {isRecording ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>
          
          <div className="relative flex-1">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              disabled={isLoading || isRecording}
              placeholder={isRecording ? "Recording audio..." : `Ask in ${mode} mode...`}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl py-3 pl-4 pr-12 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:border-transparent transition-all disabled:opacity-50"
            />
            <button
              type="submit"
              disabled={!input.trim() || isLoading || isRecording}
              className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg transition-colors disabled:opacity-50 shadow-lg shadow-indigo-600/20"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};
