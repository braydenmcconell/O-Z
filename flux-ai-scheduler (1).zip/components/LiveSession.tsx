
import React, { useEffect, useRef, useState } from 'react';
import { GoogleGenAI, Modality } from '@google/genai';
import { X, Mic, AudioLines, Info } from 'lucide-react';

interface LiveSessionProps {
  onClose: () => void;
}

// Helper functions for standard encoding/decoding as required by SDK
function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

export const LiveSession: React.FC<LiveSessionProps> = ({ onClose }) => {
  const [isActive, setIsActive] = useState(false);
  const [isConnecting, setIsConnecting] = useState(true);
  const sessionRef = useRef<any>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  useEffect(() => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
    
    const initLive = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
        const outputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        audioContextRef.current = outputCtx;

        const sessionPromise = ai.live.connect({
          model: 'gemini-2.5-flash-native-audio-preview-12-2025',
          callbacks: {
            onopen: () => {
              setIsConnecting(false);
              setIsActive(true);
              const source = inputCtx.createMediaStreamSource(stream);
              const processor = inputCtx.createScriptProcessor(4096, 1, 1);
              processor.onaudioprocess = (e) => {
                const inputData = e.inputBuffer.getChannelData(0);
                const int16 = new Int16Array(inputData.length);
                for (let i = 0; i < inputData.length; i++) {
                  int16[i] = inputData[i] * 32768;
                }
                
                const pcmData = new Uint8Array(int16.buffer);
                const base64 = encode(pcmData);
                sessionPromise.then(s => s.sendRealtimeInput({
                  media: { data: base64, mimeType: 'audio/pcm;rate=16000' }
                }));
              };
              source.connect(processor);
              processor.connect(inputCtx.destination);
            },
            onmessage: async (msg) => {
              const audioBase64 = msg.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
              if (audioBase64) {
                const bytes = decode(audioBase64);
                const dataInt16 = new Int16Array(bytes.buffer);
                const buffer = outputCtx.createBuffer(1, dataInt16.length, 24000);
                const channelData = buffer.getChannelData(0);
                for (let i = 0; i < dataInt16.length; i++) {
                  channelData[i] = dataInt16[i] / 32768.0;
                }

                const source = outputCtx.createBufferSource();
                source.buffer = buffer;
                source.connect(outputCtx.destination);
                
                const startTime = Math.max(nextStartTimeRef.current, outputCtx.currentTime);
                source.start(startTime);
                nextStartTimeRef.current = startTime + buffer.duration;
                sourcesRef.current.add(source);
                source.onended = () => sourcesRef.current.delete(source);
              }
              if (msg.serverContent?.interrupted) {
                sourcesRef.current.forEach(s => s.stop());
                sourcesRef.current.clear();
                nextStartTimeRef.current = 0;
              }
            },
            onclose: () => setIsActive(false),
            onerror: (e) => console.error("Live API Error", e)
          },
          config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } } },
            systemInstruction: 'You are Flux, a proactive scheduling assistant. You speak warmly and help the user organize their day in real-time.'
          }
        });
        
        sessionRef.current = await sessionPromise;
      } catch (err) {
        console.error("Live init failed", err);
        onClose();
      }
    };

    initLive();

    return () => {
      if (sessionRef.current) sessionRef.current.close();
      if (audioContextRef.current) audioContextRef.current.close();
    };
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/90 backdrop-blur-xl p-4">
      <div className="bg-slate-900 border border-indigo-500/30 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl shadow-indigo-500/20">
        <div className="p-6 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className={`w-3 h-3 rounded-full ${isActive ? 'bg-emerald-500 animate-pulse' : 'bg-slate-700'}`} />
            <h2 className="text-xl font-bold">Flux Live Session</h2>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-800 rounded-full transition-colors">
            <X className="w-6 h-6 text-slate-400" />
          </button>
        </div>

        <div className="p-12 flex flex-col items-center justify-center text-center space-y-8">
          <div className="relative">
            <div className={`absolute inset-0 bg-indigo-600 rounded-full blur-3xl transition-opacity duration-1000 ${isActive ? 'opacity-30' : 'opacity-0'}`} />
            <div className={`w-32 h-32 rounded-full flex items-center justify-center border-4 ${isActive ? 'border-indigo-500 bg-indigo-500/10' : 'border-slate-800 bg-slate-800'} transition-all duration-500`}>
              {isActive ? (
                <AudioLines className="w-16 h-16 text-indigo-400 animate-pulse" />
              ) : (
                <Mic className="w-16 h-16 text-slate-600" />
              )}
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-2xl font-semibold text-white">
              {isConnecting ? "Waking up Flux..." : isActive ? "Listening..." : "Paused"}
            </h3>
            <p className="text-slate-400 max-w-sm">
              Speak naturally. Flux is analyzing your voice patterns to help you schedule tasks and manage your focus time.
            </p>
          </div>

          <div className="w-full bg-slate-800/50 p-4 rounded-2xl border border-slate-700 flex items-start gap-3 text-left">
            <Info className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
            <p className="text-xs text-slate-400 leading-relaxed">
              Native Audio mode uses Gemini 2.5 for human-like response latency.
            </p>
          </div>
        </div>

        <div className="p-6 bg-slate-800/20 border-t border-slate-800 text-center">
          <p className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">Active Live Session Protocol</p>
        </div>
      </div>
    </div>
  );
};
