
import { GoogleGenAI, Type } from "@google/genai";

export class GeminiService {
  private getAI() {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
      console.warn("Gemini API Key is missing. Please ensure process.env.API_KEY is set.");
    }
    return new GoogleGenAI({ apiKey: apiKey || '' });
  }

  /**
   * Complex reasoning using Gemini 3 Pro with Thinking Budget
   */
  async getComplexResponse(prompt: string) {
    const ai = this.getAI();
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: prompt,
      config: {
        thinkingConfig: { thinkingBudget: 32768 }
      },
    });
    return {
      text: response.text,
      reasoning: response.candidates?.[0]?.content?.parts?.find(p => (p as any).thought)?.text
    };
  }

  /**
   * Audio transcription using Gemini 3 Flash
   */
  async transcribeAudio(base64Audio: string, mimeType: string) {
    const ai = this.getAI();
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [
        {
          inlineData: {
            data: base64Audio,
            mimeType: mimeType
          }
        },
        { text: "Transcribe this audio accurately. Only return the transcription text." }
      ],
    });
    return response.text;
  }

  /**
   * Search Grounding using Gemini 3 Flash
   */
  async searchWithGrounding(prompt: string) {
    const ai = this.getAI();
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }]
      }
    });
    return {
      text: response.text,
      chunks: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
    };
  }

  /**
   * Maps Grounding using Gemini 2.5 Flash
   */
  async mapsWithGrounding(prompt: string, lat?: number, lng?: number) {
    const ai = this.getAI();
    const config: any = { tools: [{ googleMaps: {} }] };
    
    if (lat && lng) {
      config.toolConfig = {
        retrievalConfig: {
          latLng: { latitude: lat, longitude: lng }
        }
      };
    }

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config
    });
    return {
      text: response.text,
      chunks: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
    };
  }

  /**
   * Core scheduler logic (fast)
   */
  async processSchedulingRequest(prompt: string) {
    const ai = this.getAI();
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              reasoning_process: {
                type: Type.OBJECT,
                properties: {
                  extracted_information: {
                    type: Type.OBJECT,
                    properties: {
                      activity: { type: Type.STRING },
                      target_date: { type: Type.STRING },
                      target_time_window: { type: Type.STRING },
                      priority: { type: Type.STRING }
                    }
                  },
                  intent_analysis: { type: Type.STRING },
                  scheduling_considerations: { type: Type.STRING }
                }
              },
              action_plan: {
                type: Type.OBJECT,
                properties: {
                  primary_action: { type: Type.STRING },
                  parameters: {
                    type: Type.OBJECT,
                    properties: {
                      title: { type: Type.STRING },
                      time: { type: Type.STRING },
                      priority: { type: Type.STRING },
                      duration: { type: Type.NUMBER },
                      dueDate: { type: Type.STRING }
                    }
                  },
                  reasoning: { type: Type.STRING },
                  user_response: { type: Type.STRING },
                  additional_suggestions: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING }
                  }
                }
              }
            }
          }
        }
      });

      return JSON.parse(response.text || '{}');
    } catch (error) {
      console.error("Gemini API Error:", error);
      throw error;
    }
  }
}

export const gemini = new GeminiService();
