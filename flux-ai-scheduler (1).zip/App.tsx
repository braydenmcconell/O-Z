
import React, { useState, useCallback } from 'react';
import { Sidebar } from './components/Sidebar.tsx';
import { CalendarView } from './components/CalendarView.tsx';
import { AIInsights } from './components/AIInsights.tsx';
import { ChatInterface } from './components/ChatInterface.tsx';
import { LiveSession } from './components/LiveSession.tsx';
import { INITIAL_SCHEDULE, INITIAL_TASKS } from './constants.tsx';
import { ScheduleItem, Task, AIActionPlan, AIReasoning, ChatMessage } from './types.ts';
import { gemini } from './services/geminiService.ts';
import { Plus, Search, Filter, Mic2 } from 'lucide-react';

const App: React.FC = () => {
  const [schedule, setSchedule] = useState<ScheduleItem[]>(INITIAL_SCHEDULE);
  const [tasks] = useState<Task[]>(INITIAL_TASKS);
  const [currentDate] = useState('Friday, Feb 13, 2026');
  
  const [loading, setLoading] = useState(false);
  const [showLive, setShowLive] = useState(false);
  const [aiReasoning, setAiReasoning] = useState<AIReasoning | null>(null);
  const [aiActionPlan, setAiActionPlan] = useState<AIActionPlan | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([
    { id: '1', role: 'assistant', content: "Hello! I'm Flux. How can I help optimize your schedule today?" }
  ]);

  const handleSendMessage = async (msg: string, mode: 'standard' | 'complex' | 'search' | 'maps' = 'standard') => {
    setLoading(true);
    setMessages(prev => [...prev, { id: Date.now().toString(), role: 'user', content: msg }]);

    try {
      let responseText = "";
      let groundingLinks: any[] = [];
      let isThinking = false;

      if (mode === 'complex') {
        isThinking = true;
        const result = await gemini.getComplexResponse(msg);
        responseText = result.text || "Reasoning complete.";
      } else if (mode === 'search') {
        const result = await gemini.searchWithGrounding(msg);
        responseText = result.text || "";
        groundingLinks = result.chunks;
      } else if (mode === 'maps') {
        const result = await gemini.mapsWithGrounding(msg);
        responseText = result.text || "";
        groundingLinks = result.chunks;
      } else {
        const schedulingData = await gemini.processSchedulingRequest(msg);
        if (schedulingData.action_plan) {
          setAiReasoning(schedulingData.reasoning_process);
          setAiActionPlan(schedulingData.action_plan);
          responseText = schedulingData.action_plan.user_response || "I've drafted a plan based on your request.";
        } else {
          const result = await gemini.searchWithGrounding(msg);
          responseText = result.text || "";
        }
      }

      setMessages(prev => [...prev, { 
        id: Date.now().toString(), 
        role: 'assistant', 
        content: responseText,
        groundingLinks,
        isThinking
      }]);
    } catch (error) {
      console.error("Failed to process message:", error);
      setMessages(prev => [...prev, { 
        id: Date.now().toString(), 
        role: 'assistant', 
        content: "I encountered an issue processing that. Could you try rephrasing?" 
      }]);
    } finally {
      setLoading(false);
    }
  };

  const handleVoiceInput = async (blob: Blob) => {
    setLoading(true);
    try {
      const reader = new FileReader();
      reader.readAsDataURL(blob);
      reader.onloadend = async () => {
        const base64 = (reader.result as string).split(',')[1];
        const transcription = await gemini.transcribeAudio(base64, blob.type);
        if (transcription) {
          handleSendMessage(transcription, 'standard');
        }
      };
    } catch (error) {
      console.error("Transcription failed", error);
    } finally {
      setLoading(false);
    }
  };

  const applyOptimization = useCallback(() => {
    if (!aiActionPlan) return;

    const newItem: ScheduleItem = {
      id: Math.random().toString(36).substr(2, 9),
      title: aiActionPlan.parameters.title,
      startTime: aiActionPlan.parameters.time,
      duration: aiActionPlan.parameters.duration,
      priority: aiActionPlan.parameters.priority,
      category: aiActionPlan.parameters.category || 'work',
      date: aiActionPlan.parameters.dueDate,
    };

    setSchedule(prev => {
      const exists = prev.find(i => i.title === newItem.title && i.startTime === newItem.startTime);
      if (exists) return prev;
      return [...prev, newItem].sort((a, b) => a.startTime.localeCompare(b.startTime));
    });

    setAiActionPlan(null);
    setAiReasoning(null);
  }, [aiActionPlan]);

  return (
    <div className="flex h-screen bg-slate-950 text-slate-200 overflow-hidden font-inter">
      <Sidebar />
      
      <main className="flex-1 flex flex-col h-full overflow-hidden relative">
        <header className="h-16 border-b border-slate-800 bg-slate-900/50 backdrop-blur-md flex items-center justify-between px-8 z-30">
          <div className="flex items-center gap-6">
            <h2 className="text-xl font-bold text-white tracking-tight">Flux Intelligence</h2>
            <div className="relative group hidden md:block">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-indigo-400 transition-colors" />
              <input 
                type="text" 
                placeholder="Search schedule..." 
                className="bg-slate-800 border-none rounded-full py-1.5 pl-10 pr-4 text-sm w-64 focus:ring-1 focus:ring-indigo-500 transition-all"
              />
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setShowLive(true)}
              className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-indigo-400 border border-indigo-500/20 rounded-lg font-medium transition-all shadow-sm"
            >
              <Mic2 className="w-4 h-4" />
              Flux Live
            </button>
            <button className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-medium transition-all shadow-lg shadow-indigo-600/20 active:scale-95">
              <Plus className="w-4 h-4" />
              New Task
            </button>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-8 grid grid-cols-12 gap-8 custom-scrollbar">
          <section className="col-span-12 lg:col-span-7 h-[calc(100vh-160px)] min-h-[600px]">
            <CalendarView items={schedule} currentDate={currentDate} />
          </section>

          <section className="col-span-12 lg:col-span-5 space-y-8">
            <AIInsights 
              reasoning={aiReasoning} 
              actionPlan={aiActionPlan} 
              onApplyAction={applyOptimization} 
            />

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl shadow-black/20">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-bold">Active Tasks</h3>
                <span className="text-xs text-slate-500 bg-slate-800 px-2 py-1 rounded-md">{tasks.filter(t => !t.completed).length} Pending</span>
              </div>
              <div className="space-y-3">
                {tasks.map((task) => (
                  <div key={task.id} className="flex items-center gap-3 p-3 bg-slate-800/30 border border-slate-800 rounded-xl hover:border-indigo-500/30 transition-all group">
                    <input 
                      type="checkbox" 
                      defaultChecked={task.completed}
                      readOnly
                      className="w-5 h-5 rounded-md border-slate-700 bg-slate-900 text-indigo-600 focus:ring-indigo-600/20 transition-all cursor-pointer"
                    />
                    <div className="flex-1">
                      <p className={`text-sm font-medium ${task.completed ? 'line-through text-slate-500' : 'text-slate-300'}`}>
                        {task.title}
                      </p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className={`text-[10px] uppercase font-bold px-1.5 py-0.5 rounded ${
                          task.priority === 'high' ? 'text-rose-400 bg-rose-400/10' :
                          task.priority === 'medium' ? 'text-amber-400 bg-amber-400/10' :
                          'text-emerald-400 bg-emerald-400/10'
                        }`}>
                          {task.priority}
                        </span>
                        <span className="text-[10px] text-slate-500 capitalize">{task.category}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>
        </div>
      </main>

      <aside className="w-96 hidden xl:block sticky top-0 border-l border-slate-800 shadow-2xl">
        <ChatInterface 
          messages={messages}
          onSendMessage={handleSendMessage} 
          onVoiceInput={handleVoiceInput}
          isLoading={loading} 
        />
      </aside>

      {showLive && <LiveSession onClose={() => setShowLive(false)} />}
    </div>
  );
};

export default App;
